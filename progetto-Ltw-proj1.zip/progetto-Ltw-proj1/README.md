# progetto-Ltw

Cosa dobbiamo fare a grandi linee

piu schacchiere bloccate dietro login

singoli pezzi personalizabili bloccati dietro login

3d / 2d

web e mobile

dark mode/ inverti colori

tasto reset

freccia per tornare indietro di x mosse

livelli / difficolta bot


4/5 pagine (gioco, registrazione( 1 pagina quando enti, rigistrazioe/login/registrati piu tardi) , personalizzazione, tutorial, parte per commenti pagina a se stante o sotto tutorial)

nella parte a sinistra c'è il menu per la navigazione delle pagine, fisso non a tendina. ci sara anche la parte per registrazione/login con menu modale(guarda chess.com)


